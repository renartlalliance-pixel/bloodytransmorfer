# BloodyTransmorpher 1.0.0

Multi-effet VST3 stéréo. Les huit sections suivent le signal de gauche à droite. Cliquer sur une section pour afficher ses trois potentiomètres. Glisser verticalement pour régler une valeur. ACTIF commute la section, AMONT et AVAL déplacent la section d’une place. Transfusion dose le signal traité en parallèle du signal direct. Les trois rangées BAS, MED et AIR suivent les crêtes par bande de la somme mono en sortie.

| Section | Traitement | Réglages |
|---|---|---|
| Suture | Porte à enveloppe | Seuil de détection, Tenue du détecteur, Fermeture de la porte |
| Braise | Saturation à courbe asymétrique | Fournaise pousse le gain, Asymétrie décale la courbe, Incandescence dose la saturation |
| Prisme | Égalisation trois bandes | Socle sous 220 Hz, Chair entre 220 Hz et 2,8 kHz, Éclat au-dessus |
| Lacet | Retard court modulé en stéréo | Orbite règle la vitesse, Étirement court produit un flanger et long un chorus, Entrelacs dose le signal retardé |
| Faille | Transposition granulaire et lecture inversée | Intervalle en demi-tons, Rebours mélange les sens de lecture, Fragments dose les grains |
| Bobine | Écho à répétitions filtrées et saturées | Distance en millisecondes, Persistance règle la réinjection, Empreinte dose le retour |
| Crypte | Réverbération à réseau de quatre retards par canal | Voûte prolonge la décroissance, Velours amortit les aigus, Brume dose la queue |
| Patine | Instabilité de bande, filtrage, souffle | Dérive mélange la bande modulée, Ouverture règle le passe-bas, Poussière dose le bruit |

MUTATION tire un parcours, des réglages et des activations. Le mélange global reste sous contrôle manuel. Pour une traîne inversée et transposée, placer Faille juste après Crypte, monter Brume et Fragments, puis régler Rebours à 100 % et Intervalle à +7.

## Gain de sortie

Le potentiomètre situé sous Transfusion ajuste le niveau des deux canaux après le mélange, de −36 à +6 dB. À 0 dB le niveau est unitaire. Le bypass restitue le signal original. Le gain est automatisable, mémorisé avec le projet et pris en compte par Annuler et Rétablir.

## Historique et bypass

Annuler et Rétablir parcourent les 64 dernières actions réalisées dans la fenêtre ouverte. Un mouvement de potentiomètre ou une génération comptent chacun pour une action. Après une annulation, un nouvel ajustement ouvre un nouvel historique à partir de cet état.

Quand le voyant de BYPASS est rouge, le plugin laisse passer le signal d’entrée à sa valeur exacte après un fondu de 5 ms. Les effets continuent à suivre le signal. Le bypass global est automatisable et mémorisé dans le projet.

## Ambiances

Choisir Trap, R&B, Lo-Fi ou Ambient puis Générer. Chaque ambiance propose 160 variations fixes issues de quatre arrangements, huit couleurs et cinq espaces. Chaque tirage parcourt la banque sans répétition pendant la session de la fenêtre. Les verrous protègent les modules. Annuler restaure les réglages et le routage précédents. Mutation reste disponible pour les tirages libres.

La banque explore les attaques sèches et les queues sombres en Trap, les retards décalés en R&B (base de 96 BPM), le grain de sample en Lo-Fi et les nappes transposées en Ambient. Ces chaînes ont été développées pour BloodyTransmorpher.

Avancé permet de réordonner les modules par glisser-déposer. Dans Suture, cliquer sur le bouton PORTE/TREMOLO pour choisir le mode. Dans Prisme, le bouton EGALISEUR/RESAMPLER active le maintien d’échantillon et la quantification.

## Version 0.2

EQ FINAL règle les graves, médiums et aigus sur ±12 dB après les huit modules et avant Transfusion. Les bandes se croisent à 220 Hz et 2,8 kHz. Les trois gains démarrent à 0 dB.

VERROU protège les trois réglages, l’activation et la place du module sélectionné lors des mutations. Le projet mémorise les verrous. ANNULER restaure la dernière mutation pendant que la fenêtre reste ouverte.

## Installation Windows

Exécuter le fichier Setup-x64.exe dans distributions, puis relancer la détection des effets. Pour reconstruire cet installateur, compiler le VST3 Windows puis lancer makensis sur installer/windows.nsi avec NSIS prenant en charge la cible amd64-unicode.

## Installation manuelle

Quitter la station audio. Extraire le dossier BloodyTransmorpher.vst3 entier dans le dossier VST3 de la plateforme, puis relancer la détection des effets.

- Windows x64 — C:\Program Files\Common Files\VST3
- Linux x86-64 — ~/.vst3

Le paquet contient les deux architectures de plateforme dans un seul bundle. Linux utilise X11 et OpenGL. Windows utilise OpenGL.

## Compiler les sources

Le dossier DPF fourni contient le framework DISTRHO et NanoVG, avec leurs licences. Le processeur, les paramètres et le panneau sont écrits pour ce projet. Depuis le dossier contenant BloodyTransmorpher et DPF, sur macOS avec les outils Xcode, ou sur Linux avec make, g++, pkg-config et les en-têtes de développement OpenGL/X11 installés, exécuter les commandes suivantes.

    make -C DPF/dgl opengl
    make -C BloodyTransmorpher vst3

Le résultat se trouve dans BloodyTransmorpher/bin. Sur Windows utiliser un environnement de compilation MinGW et GNU Make. La compilation macOS reste à valider.

![Façade de BloodyTransmorpher](media/Facade.png)

[Écoute avant et après traitement](media/Ecoute-avant-apres.wav)

## Façade et vumètres

Les deux colonnes L et R affichent les crêtes des canaux de sortie. Le PNG approuvé est intégré au binaire à la compilation avec Python 3. Depuis le sous-dossier BloodyTransmorpher, utiliser make vst3 avec les dépendances de DPF.

Les vu-mètres L et R suivent les crêtes de chaque canal après le gain de sortie et le bypass. Chaque colonne possède 16 segments. La retombée est de 36 dB par seconde.
