#pragma once
#include "DistrhoPlugin.hpp"
#include <atomic>
START_NAMESPACE_DISTRHO

// VST3 IDs 0 and 1 were reserved by the separate controller through 0.6.0.
constexpr uint32_t firstEffectParameter = 2;

class MeteredPlugin : public Plugin {
    static_assert(std::atomic<float>::is_always_lock_free, "Realtime meter requires lock-free atomics");
    std::atomic<float> pending[5]{};
protected:
    explicit MeteredPlugin(uint32_t count) : Plugin(firstEffectParameter + count, 0, 0) {}
    void publishPeak(unsigned channel, float peak) noexcept {
        float previous = pending[channel].load(std::memory_order_relaxed);
        while (previous < peak &&
               !pending[channel].compare_exchange_weak(previous, peak, std::memory_order_relaxed)) {}
    }
public:
    float takePeak(unsigned channel) noexcept {
        return pending[channel].exchange(0.f, std::memory_order_relaxed);
    }
};
END_NAMESPACE_DISTRHO
