#include "DistrhoUI.hpp"
#include "Vibes.hpp"
#include "MeteredPlugin.hpp"
#include <chrono>
#include <cstdio>
#include <deque>
#include <random>
#include <string>
START_NAMESPACE_DISTRHO
using namespace bt;
class Panel final : public UI {
  float value[Count] = {};
  int selected = 1, drag = -1;
  float origin = 0, start = 0;
  std::mt19937 rng{std::random_device{}()};
  const Color ink{21, 24, 25}, ivory{235, 230, 211}, mute{148, 157, 147},
      red{237, 95, 76}, lime{177, 214, 126};
  void box(float x, float y, float w, float h, Color colour, float r = 0) {
    beginPath();
    roundedRect(x, y, w, h, r);
    fillColor(colour);
    fill();
  }
  void dot(float x, float y, float r, Color c) {
    beginPath();
    circle(x, y, r);
    fillColor(c);
    fill();
  }
  void label(float x, float y, const char *s, float size, Color c) {
    fontSize(size);
    fillColor(c);
    text(x, y, s, nullptr);
  }
  void button(float x, float y, float w, const char *s, Color colour) {
    box(x, y, w, 29, colour, 3);
    label(x + 9, y + 20, s, 13, ink);
  }
  struct Change {
    std::array<float, Count> before{}, after{};
    std::array<bool, Count> touched{};
  };
  std::deque<Change> history;
  size_t cursor = 0;
  Change pending;
  bool grouping = false, recalling = false;
  void beginGroup() {
    pending = Change{};
    grouping = true;
  }
  void finishGroup() {
    grouping = false;
    bool any = false;
    for (int i = 0; i < Count; ++i) {
      pending.touched[i] =
          pending.touched[i] && pending.before[i] != pending.after[i];
      any |= pending.touched[i];
    }
    if (!any)
      return;
    history.erase(history.begin() + cursor, history.end());
    if (history.size() == 64)
      history.pop_front();
    history.push_back(pending);
    cursor = history.size();
    repaint();
  }
  void send(int i, float v) {
    if (value[i] == v)
      return;
    bool single = !grouping && !recalling;
    if (single)
      beginGroup();
    if (!recalling) {
      if (!pending.touched[i])
        pending.before[i] = value[i];
      pending.touched[i] = true;
      pending.after[i] = v;
    }
    value[i] = v;
    setParameterValue(firstEffectParameter + i, v);
    if (single)
      finishGroup();
    repaint();
  }
  void commit(int i, float v) {
    if (value[i] == v)
      return;
    editParameter(firstEffectParameter + i, true);
    send(i, v);
    editParameter(firstEffectParameter + i, false);
  }
  void recall(bool redo) {
    if ((redo && cursor == history.size()) || (!redo && cursor == 0))
      return;
    const auto &entry = history[redo ? cursor++ : --cursor];
    recalling = true;
    for (int i = 0; i < Count; ++i)
      if (entry.touched[i])
        commit(i, redo ? entry.after[i] : entry.before[i]);
    recalling = false;
    status = redo ? "Action retablie." : "Action annulee.";
    repaint();
  }
  void mutate() {
    auto chain = order(int(value[Route] + .5f));
    std::array<int, 8> movable{};
    int count = 0;
    for (int module : chain)
      if (value[Lock + module] < .5f)
        movable[count++] = module;
    if (count == 0)
      return;
    beginGroup();
    std::shuffle(movable.begin(), movable.begin() + count, rng);
    std::uniform_real_distribution<float> dice(0, 1);
    int next = 0;
    for (auto &slot : chain) {
      if (value[Lock + slot] >= .5f)
        continue;
      slot = movable[next++];
      for (int i = controlBase(slot); i < controlBase(slot) + 3; ++i) {
        auto c = knobControl(i);
        commit(i, c.low + (c.high - c.low) * dice(rng));
      }
      commit(Enable + slot, slot == selected || dice(rng) > .23f);
    }
    commit(Route, encode(chain));
    finishGroup();
    repaint();
  }

  Deck decks[4];
  bool advanced = false;
  int cardDrag = -1;
  float cardX = 0;
  std::string status = "";
  int controlBase(int module) const {
    if (module == 0 && value[TremMode] >= .5f)
      return Trem;
    if (module == 2 && value[SampleMode] >= .5f)
      return Sample;
    return module * 3;
  }
  const char *modeLabel(int m) const {
    if (m == 0 && value[TremMode] >= .5f)
      return "TREMOLO";
    if (m == 2 && value[SampleMode] >= .5f)
      return "RESAMPLER";
    return types[m];
  }
  void generate() {
    const int style = int(value[Vibe]);
    auto route = order(int(value[Route] + .5f));
    if (std::all_of(route.begin(), route.end(),
                    [&](int m) { return value[Lock + m] >= .5f; })) {
      status = "Tous les modules sont verrouilles.";
      repaint();
      return;
    }
    const auto &idea = bank[style * perVibe + decks[style].draw(rng)];
    beginGroup();
    auto src = idea.route.begin();
    for (int &m : route) {
      if (value[Lock + m] >= .5f)
        continue;
      while (value[Lock + *src] >= .5f)
        ++src;
      m = *src++;
      for (int k = 3 * m; k < 3 * m + 3; ++k)
        commit(k, idea.parameters[k]);
      if (m == 0 || m == 2) {
        commit(m == 0 ? TremMode : SampleMode,
               m == 0 ? idea.tremolo : idea.resampling);
        for (int k = 0; k < 3; ++k)
          commit((m == 0 ? Trem : Sample) + k,
                 idea.extra[(m == 0 ? 0 : 3) + k]);
      }
      commit(Enable + m, (idea.active >> m) & 1u);
    }
    commit(Route, encode(route));
    finishGroup();
    status = std::string(vibes[style]) + "   /   " + idea.name;
    repaint();
  }

public:
  Panel() : UI(1056, 704) {
    loadSharedResources();
    for (int i = Trem; i < Bypass; ++i)
      value[i] = knobControl(i).initial;
    for (int i = 0; i < Meter; ++i)
      value[i] = i < Enable ? controls[i].initial : 1;
    value[OutputGain] = knobControl(OutputGain).initial;
  }
  using Clock = std::chrono::steady_clock;
  Clock::time_point lastRead = Clock::now();
  void uiIdle() override {
    auto* plugin = static_cast<MeteredPlugin*>(getPluginInstancePointer());
    if (!plugin) return;
    auto now = Clock::now();
    float seconds = std::chrono::duration<float>(now - lastRead).count();
    if (seconds < 1.f / 60.f) return;
    lastRead = now;
    const float decay = std::pow(10.f, -1.8f * seconds);
    bool changed = false;
    for (unsigned ch = 0; ch < 5; ++ch) {
      const int id = ch < 3 ? Meter + ch : StereoMeter + ch - 3;
      const int count = ch < 3 ? 20 : 16;
      const float next = std::max(plugin->takePeak(ch), value[id] * decay);
      changed |= segments(next, count) != segments(value[id], count);
      value[id] = next;
    }
    if (changed) repaint();
  }
  void parameterChanged(uint32_t i, float v) override {
    if (i < firstEffectParameter) return;
    i -= firstEffectParameter;
    if ((i >= Meter && i < FinalEQ) || i >= StereoMeter) return;
    if (i < Count) {
      value[i] = v;
      repaint();
    }
  }
#include "Faceplate.inc"
  bool onMotion(const MotionEvent &e) override {
    if (drag < 0)
      return false;
    auto c = knobControl(drag);
    send(drag, std::max(c.low, std::min(c.high,
                                        start + (origin - float(e.pos.getY())) *
                                                    (c.high - c.low) / 170.f)));
    return true;
  }
};
UI *createUI() { return new Panel; }
END_NAMESPACE_DISTRHO
