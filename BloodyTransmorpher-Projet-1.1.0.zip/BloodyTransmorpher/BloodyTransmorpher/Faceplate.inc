// All positions are expressed in the native pixels of the approved faceplate.
  NanoImage face;
  static constexpr float uiScale = 1056.f / 1536.f;
  struct Bounds {
    float x, y, w, h;
    bool contains(float px, float py) const {
      return px >= x && px < x+w && py >= y && py < y+h;
    }
  };
  static constexpr int cardLeft[] = {44,229,413,596,777,959,1140,1322};
  static constexpr int cardWidth[] = {179,181,180,179,179,178,179,173};
  Bounds card(int slot) const { return {float(cardLeft[slot]),206,float(cardWidth[slot]),99}; }
  void patch(Bounds src, Bounds dst) {
    const float sx=dst.w/src.w, sy=dst.h/src.h;
    beginPath();
    rect(dst.x,dst.y,dst.w,dst.h);
    fillPaint(imagePattern(dst.x-src.x*sx,dst.y-src.y*sy,1536*sx,1024*sy,0,face,1));
    fill();
  }
  void centered(float x,float baseline,const char* s,float size,Color c) {
    textAlign(ALIGN_CENTER|ALIGN_BASELINE);
    label(x,baseline,s,size,c);
    textAlign(ALIGN_LEFT|ALIGN_BASELINE);
  }
  float ledCenter(int slot,int module) const {
    const auto dst=card(slot);
    if((module==1)!=(module==selected)) return dst.x+27;
    constexpr float centers[]={72,260,445,625,810,991,1170,1350};
    return dst.x+(centers[module]-cardLeft[module])*dst.w/cardWidth[module];
  }
  void rail(int slot,int module) {
    const Bounds dst=card(slot);
    const bool highlight=module==selected;
    const bool original=(module==1)==highlight;
    if(original) {
      if(module!=slot) patch(card(module),dst);
    } else {
      const Bounds src=card(highlight?1:0);
      patch(src,dst);
      // Stretch a clean strip of the matching machined key over its lettering.
      patch({src.x+src.w-12,215,3,74},{dst.x+13,215,dst.w-24,74});
      dot(dst.x+27,230,6,lime);
      label(dst.x+44,237,modeLabel(module),14,highlight?ink:ivory);
      label(dst.x+19,276,modules[module],28,highlight?ink:ivory);
    }
    if((module==0 && value[TremMode]>=.5f)||(module==2 && value[SampleMode]>=.5f)) {
      const auto src=card(highlight?1:0);
      patch({src.x+src.w-12,215,3,31},{dst.x+38,215,dst.w-48,31});
      label(dst.x+44,237,modeLabel(module),14,highlight?ink:ivory);
    }
    if(value[Enable+module]<.5f) {
      const float ledX=ledCenter(slot,module);
      dot(ledX,230,8,Color(52,55,48));
    }
    if(value[Lock+module]>=.5f) box(dst.x+18,287,dst.w-36,2,lime);
  }
#include "DialTicks.inc"
  struct Dial {
    float x,y,r,ring,reference,angle;
    float numberY,numberHalf;
  };
  static constexpr Dial dials[] = {
    {238,499,76,92,7,203.16f,656,108},{553,500,74,88,15,180.67f,656,105},
    {872,499,76,90,35,232.94f,656,120},{417,799,43,56,0,269.02f,920,70},
    {655,799,43,56,0,270,920,70},{896,799,43,56,0,270,920,70},
    {1291,450,45,56,100,41.52f,558,69},{1291,700,98,116,-5.9f,319.07f,847,100}
  };
  int dialId(int k) const {
    if(k<3) return controlBase(selected)+k;
    if(k<6) return FinalEQ+k-3;
    return k==6?Mix:OutputGain;
  }
  void drawDial(int k) {
    const auto &d=dials[k];
    int id=dialId(k);
    const auto &c=knobControl(id);
    const bool differentModule=k<3 && selected!=1;
    if(differentModule) {
      patch({990,595,24,37},{d.x-152,595,304,37});
      std::string title=c.name;
      for(char &ch:title) if(ch>='a'&&ch<='z') ch-=32;
      centered(d.x,621,title.c_str(),24,ivory);
    }
    const auto &arc=arcs[k];
    const float norm=std::clamp((value[id]-c.low)/(c.high-c.low),0.f,1.f);
    const float position=norm*(arc.count-1);
    const int lower=int(position);
    const int upper=std::min(lower+1,arc.count-1);
    const auto tickAngle=[&](int t) {
      const auto pt=arc.dots[t];
      float angle=std::atan2(pt.y-d.y,pt.x-d.x);
      return angle<0 ? angle+6.2831853f : angle;
    };
    const float from=tickAngle(lower);
    float to=tickAngle(upper);
    if(to<from) to+=6.2831853f;
    const float angle=from+(position-lower)*(to-from);
    save();
    translate(d.x,d.y);
    rotate(angle-d.angle*.01745329252f);
    beginPath();circle(0,0,d.r);
    fillPaint(imagePattern(-d.x,-d.y,1536,1024,0,face,1));fill();
    restore();
    const int lastLit=int(std::lround(position));
    for(int t=0;t<arc.count;++t) {
      const auto pt=arc.dots[t];
      dot(pt.x,pt.y,k==7?3.3f:2.8f,t<=lastLit?Color(189,238,106):Color(136,132,117));
    }
    if(!differentModule && std::abs(value[id]-d.reference)<.0001f) return;
    patch({k==7?1413.f:1000.f,d.numberY-26,9,32},
          {d.x-d.numberHalf,d.numberY-26,d.numberHalf*2,32});
    char num[40];
    std::snprintf(num,sizeof num,std::string(c.unit)=="%"?"%.0f %s":"%.1f %s",double(value[id]),c.unit);
    centered(d.x,d.numberY,num,k==7?27:23,Color(187,230,106));
  }
  int segments(float amplitude,int count) const {
    float db=20*std::log10(std::max(.001f,amplitude));
    return int(std::clamp((db+60)/60.f,0.f,1.f)*count+.5f);
  }
  void drawSpectrum() {
    box(46,733,268,202,Color(58,62,55),8);
    box(49,736,262,196,Color(15,21,18),6);
    label(63,762,"SPECTRE",16,ivory);
    label(228,762,"SORTIE",14,mute);
    constexpr float x=63, y=777, width=234, height=114;
    for(int j=0;j<=3;++j) {
      box(x,y+j*height/3,width,1,Color(50,60,51));
      box(x+j*width/3,y,1,height,Color(50,60,51));
    }
    for(int i=0;i<spectrumBands;++i) {
      const float h=height*analyzer.level[i];
      if(h>=.5f) box(x+i*width/spectrumBands,y+height-h,width/spectrumBands-1,h,lime);
    }
    label(x,916,"20 Hz",15,mute);

    label(246,916,"20 kHz",15,mute);
  }
  void meters() {
    for(int row=0;row<3;++row) {
      const int lit=segments(value[Meter+row],20);
      float y=35+row*28.f;
      box(574,y,259,16,Color(23,24,23));
      for(int j=0;j<20;++j)
        patch({j<lit?576.f:811.f,37,10,12},{575.f+j*12.85f,y+2,10.8f,12});
    }
    for(int side=0;side<2;++side) {
      int lit=segments(value[StereoMeter+side],16);
      float x=side?1442.f:1120.f;
      box(x-2,581,20,219,Color(22,23,22));
      for(int j=0;j<16;++j)
        patch({1122,j<lit?789.f:584.f,14,9},{x,789.f-13.7f*j,17,10});
    }
  }
  static constexpr int vibeX[]={54,202,340,478};
  static constexpr int vibeW[]={137,124,126,140};
  void onNanoDisplay() override {
    if(!face.isValid()) {
      static const unsigned char bytes[]={
#include "Facade.inc"
      };
      face=createImageFromMemory(bytes,sizeof bytes,0);
    }
    fontFace(NANOVG_DEJAVU_SANS_TTF);
    save();scale(uiScale,uiScale);
    patch({0,0,1536,1024},{0,0,1536,1024});
    // Extend the EQ frame into the lower margin, keeping its original bevel.
    patch({32,930,1027,6},{32,936,1027,15});
    patch({32,936,1027,17},{32,951,1027,17});
    int vibe=int(value[Vibe]);
    if(vibe!=0) for(int i:{0,vibe}) {
      int from=i==0?1:0;
      patch({float(vibeX[from]),138,float(vibeW[from]),53},
            {float(vibeX[i]),138,float(vibeW[i]),53});
      patch({float(vibeX[from]+12),149,3,29},{float(vibeX[i]+10),149,float(vibeW[i]-20),29});
      centered(vibeX[i]+vibeW[i]/2,171,vibes[i],20,i==vibe?ink:ivory);
    }
    auto chain=order(int(value[Route]+.5f));
    for(int k=0;k<8;++k) rail(k,chain[k]);
    if(selected!=1) {
      patch({70,380,172,13},{66,343,174,37});
      label(76,375,modules[selected],32,ivory);
    }
    if(advanced) {
      box(1371,88,98,3,lime);
      if(selected==0||selected==2) button(266,348,155,modeLabel(selected),ivory);
      button(442,348,150,value[Lock+selected]>=.5f?"VERROUILLÉ":"VERROU",ivory);
      button(603,348,125,value[Enable+selected]>=.5f?"ACTIF":"COUPÉ",ivory);
      button(739,348,130,"<  AMONT",ivory);button(880,348,130,"AVAL  >",ivory);
    }
    for(int k=0;k<8;++k) drawDial(k);
    drawSpectrum();
    meters();
    if(value[Bypass]>=.5f) dot(1220,899,8,red);
    if(!status.empty()) label(900,169,status.c_str(),17,ivory);
    restore();
  }
  int slotAt(float x,float y) const {
    for(int k=0;k<8;++k) if(card(k).contains(x,y)) return k;
    return -1;
  }
  bool onMouse(const MouseEvent &e) override {
    if(e.button!=1) return false;
    float x=e.pos.getX()/uiScale,y=e.pos.getY()/uiScale;
    const int slot=slotAt(x,y);
    auto chain=order(int(value[Route]+.5f));
    if(!e.press) {
      if(advanced && cardDrag>=0 && slot>=0 && std::abs(x-cardX)>8) {
        auto from=std::find(chain.begin(),chain.end(),cardDrag),to=chain.begin()+slot;
        if(from<to) std::rotate(from,from+1,to+1);
        if(from>to) std::rotate(to,from,from+1);
        commit(Route,encode(chain));
      }
      cardDrag=-1;
      if(drag>=0){editParameter(firstEffectParameter + drag,false);drag=-1;finishGroup();}
      return true;
    }
    if(slot>=0){
      const int module=chain[slot];
      if(std::abs(x-ledCenter(slot,module))<=18 && std::abs(y-230)<=18){
        commit(Enable+module,value[Enable+module]<.5f);
        return true;
      }
      selected=module;cardDrag=selected;cardX=x;repaint();return true;
    }
    auto hit=[&](Bounds b){return b.contains(x,y);};
    if(hit({878,49,132,47})) recall(false);
    else if(hit({1025,49,135,47})) recall(true);
    else if(hit({1174,49,151,47})) mutate();
    else if(hit({1358,49,125,47})){advanced=!advanced;repaint();}
    else if(hit({671,139,205,48})) generate();
    else if(hit({1187,875,205,46})) commit(Bypass,1-value[Bypass]);
    else if(advanced && hit({266,348,155,29}) && (selected==0||selected==2)){
      int id=selected==0?TremMode:SampleMode;commit(id,1-value[id]);
    } else if(advanced && hit({442,348,150,29})) commit(Lock+selected,1-value[Lock+selected]);
    else if(advanced && hit({603,348,125,29})) commit(Enable+selected,1-value[Enable+selected]);
    else if(advanced && (hit({739,348,130,29})||hit({880,348,130,29}))) {
      int k=std::find(chain.begin(),chain.end(),selected)-chain.begin();
      std::swap(chain[k],chain[std::clamp(k+(x<880?-1:1),0,7)]);commit(Route,encode(chain));
    } else {
      for(int i=0;i<4;++i) if(hit({float(vibeX[i]),140,float(vibeW[i]),47})){
        commit(Vibe,i);status.clear();repaint();return true;
      }
      for(int k=0;k<8;++k) {
        const auto &d=dials[k];
        if(std::hypot(x-d.x,y-d.y)>d.ring+7) continue;
        drag=dialId(k);origin=e.pos.getY();start=value[drag];beginGroup();editParameter(firstEffectParameter + drag,true);return true;
      }
      return false;
    }
    return true;
  }
