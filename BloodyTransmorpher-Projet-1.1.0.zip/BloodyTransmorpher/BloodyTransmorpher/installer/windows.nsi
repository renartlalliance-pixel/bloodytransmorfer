Unicode true
Target amd64-unicode
Name "BloodyTransmorpher 1.1.0"
OutFile "BloodyTransmorpher-1.1.0-Setup-x64.exe"
RequestExecutionLevel admin
SetCompressor /SOLID lzma
ShowInstDetails show
Page instfiles
LoadLanguageFile "${NSISDIR}/Contrib/Language files/French.nlf"
VIProductVersion "1.1.0.0"
VIAddVersionKey "ProductName" "BloodyTransmorpher"
VIAddVersionKey "FileDescription" "Installation VST3 x64"
VIAddVersionKey "FileVersion" "1.1.0"
VIAddVersionKey "LegalCopyright" "Copyright 2026"
Function .onInit
 IfSilent ready
 MessageBox MB_OKCANCEL|MB_ICONINFORMATION "Fermez votre station audio. Installer BloodyTransmorpher 1.1.0 dans $COMMONFILES64\VST3 ?" IDOK ready
 Abort
 ready:
FunctionEnd
Section
 SetOutPath "$COMMONFILES64\VST3\BloodyTransmorpher.vst3\Contents\x86_64-win"
 File /oname=BloodyTransmorpher.new "..\bin\BloodyTransmorpher.vst3\Contents\x86_64-win\BloodyTransmorpher.vst3"
 System::Call 'kernel32::MoveFileExW(w "$OUTDIR\BloodyTransmorpher.new", w "$OUTDIR\BloodyTransmorpher.vst3", i 9) i.r0'
 StrCmp $0 0 failed done
 failed:
 Delete "$OUTDIR\BloodyTransmorpher.new"
 SetErrorLevel 1
 Abort "Installation impossible. Fermez votre station audio et relancez cet installateur."
 done:
 DetailPrint "Installation terminee. Relancez la detection des VST3 dans votre station audio."
SectionEnd
