#include "MeteredPlugin.hpp"
#include "Engine.hpp"
START_NAMESPACE_DISTRHO
using namespace bt;
class Processor final : public MeteredPlugin {
  Engine engine;

public:
  Processor() : MeteredPlugin(Count) {
    for (int i = 0; i < Meter; ++i)
      engine.target[i] = i < Enable ? controls[i].initial : 1;
    for (int i = Trem; i < Bypass; ++i)
      engine.target[i] = knobControl(i).initial;
    engine.prepare(getSampleRate());
  }
  const char *getLabel() const override { return "BloodyTransmorpher"; }
  const char *getMaker() const override { return "BloodyTransmorpher"; }
  const char *getLicense() const override { return "Copyright 2026"; }
  uint32_t getVersion() const override { return d_version(1, 1, 0); }
  void initAudioPort(bool input, uint32_t i, AudioPort &p) override {
    Plugin::initAudioPort(input, i, p);
    p.groupId = kPortGroupStereo;
  }
  void initParameter(uint32_t i, Parameter &p) override {
    if (i < firstEffectParameter) {
      p.name = i == 0 ? "Buffer Size" : "Sample Rate";
      p.symbol = i == 0 ? "buffer_size" : "sample_rate";
      p.hints = kParameterIsOutput | kParameterIsHidden;
      p.ranges.max = i == 0 ? 1048576.f : 768000.f;
      return;
    }
    i -= firstEffectParameter;
    p.hints = kParameterIsAutomatable;
    if (i == Bypass) {
      p.initDesignation(kParameterDesignationBypass);
      return;
    }
    if (i >= StereoMeter) {
      p.name = i == StereoMeter ? "Sortie L" : "Sortie R";
      p.symbol = i == StereoMeter ? "peak_l" : "peak_r";
      p.hints = kParameterIsOutput;
    } else if (i == Vibe) {
      p.name = "Ambiance";
      p.symbol = "vibe";
      p.ranges.max = 3;
      p.hints |= kParameterIsInteger;
    } else if (i == TremMode || i == SampleMode) {
      p.name = i == TremMode ? "Mode tremolo" : "Mode resampling";
      p.symbol = i == TremMode ? "trem_mode" : "sample_mode";
      p.hints |= kParameterIsBoolean;
    } else if (i >= Trem || i < Enable || (i >= FinalEQ && i < Lock)) {
      const auto &c = knobControl(i);
      p.name = c.name;
      p.symbol = c.symbol;
      p.unit = c.unit;
      p.ranges.min = c.low;
      p.ranges.max = c.high;
      p.ranges.def = c.initial;
      if (i == Route)
        p.hints |= kParameterIsInteger;
    } else if (i < Meter) {
      p.name = String(modules[i - Enable]) + " actif";
      p.symbol = String("active_") + modules[i - Enable];
      p.ranges.def = 1;
      p.hints |= kParameterIsBoolean;
    } else if (i >= Lock) {
      p.name = String("Verrou ") + modules[i - Lock];
      p.symbol = String("lock_") + modules[i - Lock];
      p.ranges.def = 0;
      p.hints |= kParameterIsBoolean;
    } else {
      const char *names[] = {"Bas", "Medium", "Haut"};
      p.name = names[i - Meter];
      p.symbol = String("vu_") + names[i - Meter];
      p.hints = kParameterIsOutput;
    }
  }
  float getParameterValue(uint32_t i) const override {
    if (i < firstEffectParameter) return i == 0 ? getBufferSize() : getSampleRate();
    i -= firstEffectParameter;
    if (i >= StereoMeter) return std::min(1.f, engine.peak[i - StereoMeter]);
    return (i < Meter || i >= FinalEQ) ? engine.target[i]
                                       : std::min(1.f, engine.band[i - Meter]);
  }
  void setParameterValue(uint32_t i, float v) override {
    if (i < firstEffectParameter) return;
    i -= firstEffectParameter;
    if (i >= StereoMeter) return;
    if (i == Bypass) {
      engine.target[i] = float(v >= .5f);
      return;
    }
    if (i == Vibe) {
      if (std::isfinite(v))
        engine.target[i] = std::round(std::max(0.f, std::min(3.f, v)));
      return;
    }
    if ((i < Meter || (i >= FinalEQ && i < Count)) && std::isfinite(v))
      engine.target[i] =
          (i >= Trem || i < Enable || (i >= FinalEQ && i < Lock))
              ? std::max(knobControl(i).low, std::min(v, knobControl(i).high))
              : float(v >= .5f);
  }
  void activate() override { engine.prepare(getSampleRate()); }
  void run(const float **in, float **out, uint32_t frames) override {
    engine.process(in, out, frames);
    spectrum.append(out[0], out[1], frames, getSampleRate());
    for (unsigned i = 0; i < 3; ++i) publishPeak(i, engine.band[i]);
    for (unsigned i = 0; i < 2; ++i) publishPeak(3 + i, engine.peak[i]);
  }
};
Plugin *createPlugin() { return new Processor; }
END_NAMESPACE_DISTRHO
