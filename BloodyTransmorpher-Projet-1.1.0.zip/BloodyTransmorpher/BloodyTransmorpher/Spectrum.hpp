#pragma once
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <complex>

namespace bt {
constexpr int fftSize = 4096;
constexpr int spectrumBands = 48;

// One requested frame at a time. The audio callback never waits for the editor.
struct SpectrumCapture {
    using Sample = std::complex<float>;
    std::array<Sample, fftSize> samples{};
    float rate = 0;
    enum State { idle, requested, ready };
    std::atomic<int> state{idle};
    static_assert(std::atomic<int>::is_always_lock_free);
    int filled = 0;

    void append(const float* left, const float* right, unsigned frames, float hz) {
        if (state.load(std::memory_order_acquire) != requested) return;
        if (rate != hz) { filled = 0; rate = hz; }
        const unsigned count = std::min<unsigned>(frames, fftSize - filled);
        for (unsigned i = 0; i < count; ++i) samples[filled++] = {left[i],right[i]};
        if (filled == fftSize) {
            filled = 0;
            state.store(ready, std::memory_order_release);
        }
    }
};

class SpectrumDisplay {
    using Sample = SpectrumCapture::Sample;
    std::array<float, fftSize> window{};
    std::array<Sample, fftSize/2> roots{};
    std::array<Sample, fftSize> fft{};
public:
    std::array<float,spectrumBands> level{};
    SpectrumDisplay() {
        constexpr float tau = 6.28318530718f;
        for (int i=0; i<fftSize; ++i) window[i] = .5f-.5f*std::cos(tau*i/fftSize);
        for (int k=0; k<fftSize/2; ++k) roots[k] = std::polar(1.f,-tau*k/fftSize);
    }
    bool refresh(SpectrumCapture& capture, float seconds) {
        const int state = capture.state.load(std::memory_order_acquire);
        std::array<float,spectrumBands> target{};
        if (state == SpectrumCapture::ready) {
            const float rate = capture.rate;
            for (int i=0,j=0; i<fftSize; ++i) {
                fft[j] = capture.samples[i]*window[i];
                int bit=fftSize/2;
                while (bit && (j&bit)) { j ^= bit; bit >>= 1; }
                j ^= bit;
            }
            capture.state.store(SpectrumCapture::requested,std::memory_order_release);
            for (int size=2; size<=fftSize; size*=2) {
                for (int start=0; start<fftSize; start+=size) {
                    for (int j=0; j<size/2; ++j) {
                        const int k=start+j;
                        const Sample odd=fft[k+size/2]*roots[j*(fftSize/size)];
                        const Sample even=fft[k];
                        fft[k]=even+odd;
                        fft[k+size/2]=even-odd;
                    }
                }
            }
            // Symmetric FFT bins recover combined stereo energy, including opposite polarity.
            for (int k=1;k<fftSize/2;++k) {
                const float hz=k*rate/fftSize;
                if (hz<20 || hz>20000) continue;
                const int band=std::min(spectrumBands-1,int(std::log10(hz/20)*spectrumBands/3));
                const float amplitude=2.f/fftSize*std::sqrt(std::norm(fft[k])+std::norm(fft[fftSize-k]));
                const float height=std::clamp(1.f+20.f/72*std::log10(std::max(1e-8f,amplitude)),0.f,1.f);
                target[band]=std::max(target[band],height);
            }
        } else if (state == SpectrumCapture::idle) {
            capture.state.store(SpectrumCapture::requested,std::memory_order_release);
        }
        bool changed=false;
        for (int i=0;i<spectrumBands;++i) {
            const float next=std::max(target[i],level[i]-seconds*.52f);
            changed |= next != level[i];
            level[i]=next;
        }
        return changed;
    }
};
}
