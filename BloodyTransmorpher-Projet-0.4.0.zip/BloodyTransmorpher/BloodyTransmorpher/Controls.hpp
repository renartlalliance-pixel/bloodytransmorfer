#pragma once
#include <algorithm>
#include <array>
#include <cmath>
namespace bt {
struct Control {
  const char *name, *symbol, *unit;
  float low, high, initial;
};
constexpr const char *modules[] = {"Suture", "Braise", "Prisme", "Lacet",
                                   "Faille", "Bobine", "Crypte", "Patine"};
constexpr const char *types[] = {"PORTE",         "SATURATION", "EGALISEUR",
                                 "MODULATION",    "GRAINS",     "ECHO",
                                 "REVERBERATION", "BANDE"};
constexpr Control controls[] = {
    {"Seuil", "threshold", "dB", -72, -12, -48},
    {"Tenue", "release", "ms", 10, 400, 110},
    {"Fermeture", "closure", "%", 0, 100, 0},
    {"Fournaise", "drive", "dB", 0, 30, 7},
    {"Asymetrie", "bias", "%", 0, 100, 15},
    {"Incandescence", "heat", "%", 0, 100, 35},
    {"Socle", "bass", "dB", -12, 12, 0},
    {"Chair", "body", "dB", -12, 12, 0},
    {"Eclat", "air", "dB", -12, 12, 0},
    {"Orbite", "rate", "Hz", 0.05, 5, 0.32},
    {"Etirement", "width", "ms", 0.4, 24, 14},
    {"Entrelacs", "weave", "%", 0, 100, 17},
    {"Intervalle", "pitch", "st", -12, 12, 7},
    {"Rebours", "reverse", "%", 0, 100, 0},
    {"Fragments", "grains", "%", 0, 100, 0},
    {"Distance", "time", "ms", 35, 900, 295},
    {"Persistance", "feedback", "%", 0, 86, 34},
    {"Empreinte", "echo", "%", 0, 100, 14},
    {"Voute", "decay", "%", 0, 95, 58},
    {"Velours", "damp", "%", 0, 100, 39},
    {"Brume", "space", "%", 0, 100, 16},
    {"Derive", "wow", "%", 0, 100, 0},
    {"Ouverture", "cutoff", "Hz", 400, 20000, 20000},
    {"Poussiere", "dust", "%", 0, 100, 0},
    {"Transfusion", "mix", "%", 0, 100, 100},
    {"Parcours", "route", "", 0, 40319, 0}};
constexpr int Mix = 24, Route = 25, Enable = 26, Meter = 34, FinalEQ = 37,
              Lock = 40, Vibe = 48, TremMode = 49, SampleMode = 50, Trem = 51,
              Sample = 54, Bypass = 57, Count = 58;
constexpr Control finalBands[] = {{"Graves", "final_low", "dB", -12, 12, 0},
                                  {"Mediums", "final_mid", "dB", -12, 12, 0},
                                  {"Aigus", "final_high", "dB", -12, 12, 0}};
inline const Control &knobControl(int index) {
  static constexpr Control extra[] = {
      {"Pulsation", "pulse_rate", "Hz", 0.2, 16, 4},
      {"Decoupe", "pulse_shape", "%", 0, 100, 15},
      {"Profondeur", "pulse_depth", "%", 0, 100, 55},
      {"Cadence", "sample_rate_fx", "Hz", 1000, 32000, 11025},
      {"Resolution", "sample_bits", "bits", 4, 16, 12},
      {"Patine PCM", "sample_mix", "%", 0, 100, 40}};
  if (index >= Trem)
    return extra[index - Trem];
  return index >= FinalEQ ? finalBands[index - FinalEQ] : controls[index];
}
inline std::array<int, 8> order(int code) {
  std::array<int, 8> a{{0, 1, 2, 3, 4, 5, 6, 7}};
  for (int i = 0; i < 7; ++i) {
    int n = 8 - i, k = code % n;
    code /= n;
    std::rotate(a.begin() + i, a.begin() + i + k, a.begin() + i + k + 1);
  }
  return a;
}
inline int encode(std::array<int, 8> desired) {
  auto a = order(0);
  int code = 0, m = 1;
  for (int i = 0; i < 7; ++i) {
    auto it = std::find(a.begin() + i, a.end(), desired[i]);
    code += m * int(it - a.begin() - i);
    m *= 8 - i;
    std::rotate(a.begin() + i, it, it + 1);
  }
  return code;
}
} // namespace bt
