#include "DistrhoUI.hpp"
#include "PresetFile.hpp"
#include "Vibes.hpp"
#include <cstdio>
#include <deque>
#include <random>
START_NAMESPACE_DISTRHO
using namespace bt;
class Panel final : public UI {
  float value[Count] = {};
  int selected = 1, drag = -1;
  float origin = 0, start = 0;
  std::mt19937 rng{std::random_device{}()};
  const Color ink{21, 24, 25}, ivory{235, 230, 211}, mute{148, 157, 147},
      red{237, 95, 76}, lime{177, 214, 126};
  void box(float x, float y, float w, float h, Color colour, float r = 0) {
    beginPath();
    roundedRect(x, y, w, h, r);
    fillColor(colour);
    fill();
  }
  void dot(float x, float y, float r, Color c) {
    beginPath();
    circle(x, y, r);
    fillColor(c);
    fill();
  }
  void label(float x, float y, const char *s, float size, Color c) {
    fontSize(size);
    fillColor(c);
    text(x, y, s, nullptr);
  }
  void button(float x, float y, float w, const char *s, Color colour) {
    box(x, y, w, 29, colour, 3);
    label(x + 9, y + 20, s, 13, ink);
  }
  void knob(int i, float x, float y, float r) {
    auto c = knobControl(i);
    float norm = (value[i] - c.low) / (c.high - c.low);
    for (int tick = 0; tick <= 24; ++tick) {
      float angle = 2.35f + 4.72f * tick / 24;
      dot(x + (r + 6) * std::cos(angle), y + (r + 6) * std::sin(angle), 1.4f,
          tick <= norm * 24 ? lime : mute);
    }
    dot(x, y + 3, r + 1, Color(9, 11, 11));
    beginPath();
    circle(x, y, r);
    fillPaint(linearGradient(x - r, y - r, x + r, y + r, Color(89, 95, 92),
                             Color(30, 33, 34)));
    fill();
    float angle = 2.35f + 4.72f * norm;
    beginPath();
    moveTo(x + .52 * r * std::cos(angle), y + .52 * r * std::sin(angle));
    lineTo(x + .91 * r * std::cos(angle), y + .91 * r * std::sin(angle));
    strokeWidth(3);
    strokeColor(ivory);
    stroke();
    char number[48];
    std::snprintf(number, sizeof(number), "%.1f %s", double(value[i]), c.unit);
    textAlign(ALIGN_CENTER | ALIGN_BASELINE);
    label(x, y + r + 23, c.name, 16, ivory);
    label(x, y + r + 44, number, 13, lime);
    textAlign(ALIGN_LEFT | ALIGN_BASELINE);
  }
  struct Change {
    Snapshot before{}, after{};
    std::array<bool, Count> touched{};
  };
  std::deque<Change> history;
  size_t cursor = 0;
  Change pending;
  bool grouping = false, recalling = false;
  void beginGroup() {
    pending = Change{};
    grouping = true;
  }
  void finishGroup() {
    grouping = false;
    bool any = false;
    for (int i = 0; i < Count; ++i) {
      pending.touched[i] =
          pending.touched[i] && pending.before[i] != pending.after[i];
      any |= pending.touched[i];
    }
    if (!any)
      return;
    history.erase(history.begin() + cursor, history.end());
    if (history.size() == 64)
      history.pop_front();
    history.push_back(pending);
    cursor = history.size();
    repaint();
  }
  void send(int i, float v) {
    if (value[i] == v)
      return;
    bool single = !grouping && !recalling;
    if (single)
      beginGroup();
    if (!recalling) {
      if (!pending.touched[i])
        pending.before[i] = value[i];
      pending.touched[i] = true;
      pending.after[i] = v;
    }
    value[i] = v;
    setParameterValue(i, v);
    if (single)
      finishGroup();
    repaint();
  }
  void commit(int i, float v) {
    if (value[i] == v)
      return;
    editParameter(i, true);
    send(i, v);
    editParameter(i, false);
  }
  void recall(bool redo) {
    if ((redo && cursor == history.size()) || (!redo && cursor == 0))
      return;
    const auto &entry = history[redo ? cursor++ : --cursor];
    recalling = true;
    for (int i = 0; i < Count; ++i)
      if (entry.touched[i])
        commit(i, redo ? entry.after[i] : entry.before[i]);
    recalling = false;
    status = redo ? "Action retablie." : "Action annulee.";
    repaint();
  }
  void mutate() {
    auto chain = order(int(value[Route] + .5f));
    std::array<int, 8> movable{};
    int count = 0;
    for (int module : chain)
      if (value[Lock + module] < .5f)
        movable[count++] = module;
    if (count == 0)
      return;
    beginGroup();
    std::shuffle(movable.begin(), movable.begin() + count, rng);
    std::uniform_real_distribution<float> dice(0, 1);
    int next = 0;
    for (auto &slot : chain) {
      if (value[Lock + slot] >= .5f)
        continue;
      slot = movable[next++];
      for (int i = controlBase(slot); i < controlBase(slot) + 3; ++i) {
        auto c = knobControl(i);
        commit(i, c.low + (c.high - c.low) * dice(rng));
      }
      commit(Enable + slot, slot == selected || dice(rng) > .23f);
    }
    commit(Route, encode(chain));
    finishGroup();
    repaint();
  }

  Deck decks[4];
  bool advanced = false, saving = false;
  int cardDrag = -1;
  float cardX = 0;
  std::string status = "";
  int controlBase(int module) const {
    if (module == 0 && value[TremMode] >= .5f)
      return Trem;
    if (module == 2 && value[SampleMode] >= .5f)
      return Sample;
    return module * 3;
  }
  const char *modeLabel(int m) const {
    if (m == 0 && value[TremMode] >= .5f)
      return "TREMOLO";
    if (m == 2 && value[SampleMode] >= .5f)
      return "RESAMPLER";
    return types[m];
  }
  void generate() {
    const int style = int(value[Vibe]);
    auto route = order(int(value[Route] + .5f));
    if (std::all_of(route.begin(), route.end(),
                    [&](int m) { return value[Lock + m] >= .5f; })) {
      status = "Tous les modules sont verrouilles.";
      repaint();
      return;
    }
    const auto &idea = bank[style * perVibe + decks[style].draw(rng)];
    beginGroup();
    auto src = idea.route.begin();
    for (int &m : route) {
      if (value[Lock + m] >= .5f)
        continue;
      while (value[Lock + *src] >= .5f)
        ++src;
      m = *src++;
      for (int k = 3 * m; k < 3 * m + 3; ++k)
        commit(k, idea.parameters[k]);
      if (m == 0 || m == 2) {
        commit(m == 0 ? TremMode : SampleMode,
               m == 0 ? idea.tremolo : idea.resampling);
        for (int k = 0; k < 3; ++k)
          commit((m == 0 ? Trem : Sample) + k,
                 idea.extra[(m == 0 ? 0 : 3) + k]);
      }
      commit(Enable + m, (idea.active >> m) & 1u);
    }
    commit(Route, encode(route));
    finishGroup();
    status = std::string(vibes[style]) + "   /   " + idea.name;
    repaint();
  }
  void presetDialog(bool save) {
    saving = save;
    FileBrowserOptions opts;
    opts.saving = save;
    opts.defaultName = save ? "Ma chaine.btchain" : nullptr;
    opts.title = save ? "Sauvegarder la chaine" : "Charger une chaine";
    if (!openFileBrowser(opts)) {
      status = "Ouverture du selecteur impossible.";
      repaint();
    }
  }
  void uiFileBrowserSelected(const char *file) override {
    if (!file)
      return;
    try {
      auto path = std::filesystem::u8path(file);
      if (saving) {
        status = writePreset(path, value) ? "Preset sauvegarde."
                                          : "Echec de la sauvegarde.";
      } else {
        Snapshot loaded;
        if (readPreset(path, loaded)) {
          beginGroup();
          for (int i = 0; i < Bypass; ++i)
            if (i < Meter || i >= FinalEQ)
              commit(i, loaded[i]);
          finishGroup();
          status = "Preset charge.";
        } else
          status = "Fichier de preset invalide.";
      }
    } catch (const std::exception &) {
      status = "Fichier inaccessible.";
    }
    repaint();
  }

public:
  Panel() : UI(828, 662) {
    loadSharedResources();
    for (int i = Trem; i < Bypass; ++i)
      value[i] = knobControl(i).initial;
    for (int i = 0; i < Meter; ++i)
      value[i] = i < Enable ? controls[i].initial : 1;
    setGeometryConstraints(828, 662, true, true);
  }
  void parameterChanged(uint32_t i, float v) override {
    if (i < Count) {
      value[i] = v;
      repaint();
    }
  }
  void onNanoDisplay() override {
    fontFace(NANOVG_DEJAVU_SANS_TTF);
    box(0, 0, 828, 662, ink);
    box(20, 24, 6, 44, red);
    label(38, 43, "BLOODY", 19, red);
    label(37, 71, "Transmorpher", 35, ivory);
    for (int i = 0; i < 3; ++i) {
      const char *b[] = {"BAS", "MED", "AIR"};
      label(306, 32 + 16 * i, b[i], 10, mute);
      float db = 20 * std::log10(std::max(.001f, value[Meter + i]));
      for (int k = 0; k < 18; ++k)
        box(340 + 7 * k, 24 + 16 * i, 5, 6,
            k < (db + 60) * .3 ? lime : Color(55, 62, 57));
    }
    button(483, 32, 88, "ANNULER", cursor ? ivory : mute);
    button(579, 32, 86, "RETABLIR", cursor < history.size() ? ivory : mute);
    button(674, 32, 130, "MUTATION   *", ivory);
    for (int i = 0; i < 4; ++i)
      button(20 + 74 * i, 91, 70, vibes[i],
             int(value[Vibe]) == i ? lime : mute);
    button(329, 91, 102, "GENERER", ivory);
    button(444, 91, 105, "AVANCE", advanced ? lime : mute);
    button(560, 91, 116, "SAUVER", ivory);
    button(686, 91, 118, "CHARGER", ivory);
    if (!status.empty())
      label(22, 143, status.c_str(), 13, mute);
    translate(0, 56);
    auto chain = order(int(value[Route] + .5f));
    for (int k = 0; k < 8; ++k) {
      int m = chain[k], x = 20 + 99 * k;
      box(x, 99, 95, 57, m == selected ? ivory : Color(47, 52, 52), 3);
      dot(x + 11, 113, 3, value[Enable + m] > .5 ? lime : mute);
      label(x + 22, 117, modeLabel(m), 9, m == selected ? ink : mute);
      if (value[Lock + m] > .5f)
        box(x + 6, 151, 83, 2, lime);
      label(x + 8, 144, modules[m], 18, m == selected ? ink : ivory);
    }
    box(20, 179, 585, 263, Color(38, 42, 42), 5);
    box(622, 179, 182, 404, Color(44, 48, 45), 5);
    if ((selected == 0 || selected == 2) && advanced)
      button(40, 190, 150, modeLabel(selected), ivory);
    else
      label(40, 213, modeLabel(selected), 14, mute);
    if (advanced) {
      button(218, 190, 110,
             value[Lock + selected] > .5f ? "VERROUILLE" : "VERROU",
             value[Lock + selected] > .5f ? lime : ivory);
      button(337, 190, 78, value[Enable + selected] > .5 ? "ACTIF" : "COUPE",
             value[Enable + selected] > .5 ? lime : mute);
      button(428, 190, 74, "<  AMONT", ivory);
      button(509, 190, 78, "AVAL  >", ivory);
    }
    for (int k = 0; k < 3; ++k)
      knob(controlBase(selected) + k, 123 + 191 * k, 310, 40);
    box(20, 452, 585, 131, Color(38, 42, 42), 5);
    label(36, 480, "EQ FINAL", 15, ivory);
    label(36, 507, "220 Hz", 13, mute);
    label(36, 527, "2,8 kHz", 13, mute);
    for (int k = 0; k < 3; ++k)
      knob(FinalEQ + k, 216 + 148 * k, 499, 25);
    label(647, 213, "SORTIE", 14, mute);
    knob(Mix, 713, 310, 45);
    button(650, 449, 126, value[Bypass] >= .5f ? "BYPASS  ON" : "BYPASS  OFF",
           value[Bypass] >= .5f ? red : ivory);
  }
  bool onMouse(const MouseEvent &e) override {
    if (e.button != 1)
      return false;
    float x = e.pos.getX(), y = e.pos.getY();
    if (!e.press) {
      if (cardDrag >= 0) {
        if (advanced && y >= 155 && y < 212 && x >= 20 && x < 812 &&
            std::abs(x - cardX) > 8) {
          auto chain = order(int(value[Route] + .5f));
          auto from = std::find(chain.begin(), chain.end(), cardDrag);
          auto to = chain.begin() + int(x - 20) / 99;
          if (from < to)
            std::rotate(from, from + 1, to + 1);
          if (from > to)
            std::rotate(to, from, from + 1);
          commit(Route, encode(chain));
        }
        cardDrag = -1;
      }
      if (drag >= 0) {
        editParameter(drag, false);
        drag = -1;
        finishGroup();
      }
      return true;
    }
    if (y >= 91 && y <= 120) {
      if (x >= 20 && x < 316 && int(x - 20) % 74 < 70) {
        commit(Vibe, int(x - 20) / 74);
        status.clear();
        repaint();
      } else if (x >= 329 && x <= 431)
        generate();
      else if (x >= 444 && x <= 549) {
        advanced = !advanced;
        repaint();
      } else if (x >= 560 && x <= 676)
        presetDialog(true);
      else if (x >= 686 && x <= 804)
        presetDialog(false);
      return true;
    }
    if (y >= 149)
      y -= 56;
    else if (y >= 90)
      return false;
    auto chain = order(int(value[Route] + .5f));
    if (y >= 99 && y < 156 && x >= 20 && x < 812 && int(x - 20) % 99 < 95) {
      selected = chain[int(x - 20) / 99];
      cardDrag = selected;
      cardX = x;
      repaint();
      return true;
    }
    if (y >= 32 && y <= 61) {
      if (x >= 483 && x <= 571) {
        recall(false);
        return true;
      }
      if (x >= 579 && x <= 665) {
        recall(true);
        return true;
      }
    }
    if (y >= 449 && y <= 478 && x >= 650 && x <= 776) {
      commit(Bypass, 1 - value[Bypass]);
      return true;
    }
    if (y >= 458 && y <= 575) {
      for (int k = 0; k < 3; ++k)
        if (std::abs(x - (216 + 148 * k)) < 58) {
          drag = FinalEQ + k;
          origin = e.pos.getY();
          start = value[drag];
          beginGroup();
          editParameter(drag, true);
          return true;
        }
    }
    if (y >= 32 && y <= 61 && x >= 674 && x <= 804) {
      mutate();
      status = "Mutation libre.";
      repaint();
      return true;
    }
    if (advanced && y >= 190 && y <= 219) {
      if (x >= 40 && x <= 190 && (selected == 0 || selected == 2)) {
        int i = selected == 0 ? TremMode : SampleMode;
        commit(i, 1 - value[i]);
        return true;
      }
      if (x >= 218 && x <= 328) {
        commit(Lock + selected, 1 - value[Lock + selected]);
        return true;
      }
      if (x >= 337 && x <= 415) {
        commit(Enable + selected, 1 - value[Enable + selected]);
        return true;
      }
      if ((x >= 428 && x <= 502) || (x >= 509 && x <= 587)) {
        int k = int(std::find(chain.begin(), chain.end(), selected) -
                    chain.begin());
        std::swap(chain[k],
                  chain[std::max(0, std::min(7, k + (x < 505 ? -1 : 1)))]);
        commit(Route, encode(chain));
        return true;
      }
    }
    if (y >= 252 && y <= 399) {
      for (int k = 0; k < 4; ++k) {
        float cx = k == 3 ? 713 : 123 + 191 * k;
        if (std::abs(x - cx) < 64) {
          drag = k == 3 ? Mix : controlBase(selected) + k;
          origin = e.pos.getY();
          start = value[drag];
          beginGroup();
          editParameter(drag, true);
          return true;
        }
      }
    }
    return false;
  }
  bool onMotion(const MotionEvent &e) override {
    if (drag < 0)
      return false;
    auto c = knobControl(drag);
    send(drag, std::max(c.low, std::min(c.high,
                                        start + (origin - float(e.pos.getY())) *
                                                    (c.high - c.low) / 170.f)));
    return true;
  }
};
UI *createUI() { return new Panel; }
END_NAMESPACE_DISTRHO
