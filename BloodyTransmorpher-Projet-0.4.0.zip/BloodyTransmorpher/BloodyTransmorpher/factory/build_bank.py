"""Compile fixed voicing, colour and space arrangements into the factory bank."""
from pathlib import Path
# Eight modules in parameter order, three values each.
styles = [
 ("Trap", [-40,65,68, 11,23,52, -2,1,2, .32,3,9, -12,0,12, 172,23,14, 32,46,10, 3,16000,0]),
 ("R&B", [-57,180,18, 5,32,24, 1,1,-1, .25,17,29, 7,0,7, 325,29,18, 53,52,20, 7,15200,1]),
 ("Lo-Fi", [-56,165,12, 9,45,44, 2,1,-3, .52,13,20, -5,18,10, 246,38,18, 37,68,16, 34,4700,7]),
 ("Ambient", [-65,320,8, 4,18,20, -3,0,2, .13,21,32, 7,45,30, 550,56,32, 84,46,41, 14,14300,1])]
# Each voicing specifies the order, enabled modules and granular interval.
voicings=[
 [("Impact","01273456","012567", -12),("Chrome","10234576","0123456",7),("Minuit","27103456","123457", -5),("Sillage","02137546","0124567",12)],
 [("Velours","12703456","123567",7),("Ivoire","01273564","123456",12),("Soie","21370456","123467",-5),("Halo","01237546","1234567",5)],
 [("Cassette","07123546","123567",-12),("Grenat","21730546","123457",-5),("Poussiere","72103456","123567",7),("Collage","17032465","1234567",-7)],
 [("Horizon","20341756","234567",7),("Orbite","12360547","1234567",12),("Nacre","30214657","234567",5),("Maree","71235460","1234567",-5)]]
colours=[("Doux",-3,-10,-2,.78),("Clair",-2,0,2,1.15),("Dense",4,8,-1,.91),("Fibre",2,14,0,.83),("Ombre",1,5,-3,.69),("Cuivre",3,10,1,.96),("Verre",-1,-5,3,1.1),("Satin",0,-3,0,1.0)]
spaces=[("Proche",.65,.50,-14),("Court",.78,.74,-6),("Large",1,1,0),("Long",1.26,1.19,6),("Flottant",1.49,1.38,11)]
rows=[]
for genre,(_,base) in enumerate(styles):
 for name,route,active,interval in voicings[genre]:
  for colour,drive,tilt,air,cut in colours:
   for space,time,level,decay in spaces:
    p=base.copy()
    p[3]=max(0,p[3]+drive);p[4]+=tilt;p[8]+=air;p[12]=interval
    p[15]*=time;p[16]+=decay*.55;p[17]*=level;p[18]=min(95,p[18]+decay);p[20]*=level;p[22]=min(20000,p[22]*cut)
    if genre==0: # Dry foreground against dark, pitched tails
     p[2]=min(90,p[2]+10);p[22]=min(p[22],11500*cut);p[17]*=.84
    elif genre==1: # Off-beat repeats and a wide chorus; 96 BPM reference
     p[15]=[156.25,234.375,312.5,468.75,625][spaces.index((space,time,level,decay))]
     p[2]=30;p[10]=min(24,p[10]+drive)
    elif genre==2: # Worn sample colour, short room, slow tape wobble
     p[21]=max(0,p[21]+tilt);p[19]=78;p[20]*=.8
    else: # Pitched swells, long diffuse space
     p[13]=max(0,min(100,45+decay*2));p[14]+=drive;p[11]+=air*2
    values=', '.join(f'{x:.5f}f' for x in p)
    trem=int((genre==1 and name in ("Soie","Halo")) or (genre==0 and name=="Chrome") or (genre==3 and name=="Maree"))
    resample=int((genre==2 and name!="Grenat") or (genre==0 and name=="Impact"))
    pulse=[4.67,3.2,2.7,0.46][genre]*time
    hz=[22050,26000,11025,28000][genre]*cut
    extra=[pulse,[68,34,20,8][genre],max(10,38+decay),min(hz,32000),[12,14,10,15][genre],max(10,40+tilt)]
    mask=sum(1<<int(x) for x in active)|(1 if trem else 0)|(4 if resample else 0)
    rows.append('{"%s / %s / %s", {%s}, {%s}, %d, %d, %d, {%s}},'%(name,colour,space,values,', '.join(route),mask,trem,resample,', '.join(f'{x:.5f}f' for x in extra)))

Path(__file__).with_name('Bank.inc').write_text('\n'.join(rows)+'\n')
