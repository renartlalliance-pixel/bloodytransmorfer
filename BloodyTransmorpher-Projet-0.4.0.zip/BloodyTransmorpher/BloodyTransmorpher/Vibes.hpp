#pragma once
#include "Controls.hpp"
#include <random>
namespace bt {
struct FactoryChain {
  const char *name;
  std::array<float, Mix> parameters;
  std::array<int, 8> route;
  unsigned active;
  int tremolo, resampling;
  std::array<float, 6> extra;
};
constexpr const char *vibes[] = {"Trap", "R&B", "Lo-Fi", "Ambient"};
constexpr FactoryChain bank[] = {
#include "factory/Bank.inc"
};
constexpr int perVibe = 160;
static_assert(sizeof(bank) / sizeof(*bank) == 4 * perVibe,
              "Invalid factory bank");
struct Deck {
  std::array<int, perVibe> entries{};
  int cursor = perVibe, last = -1;
  int draw(std::mt19937 &rng) {
    if (cursor == perVibe) {
      for (int i = 0; i < perVibe; ++i)
        entries[i] = i;
      std::shuffle(entries.begin(), entries.end(), rng);
      if (entries.front() == last)
        std::swap(entries.front(), entries.back());
      cursor = 0;
    }
    return last = entries[cursor++];
  }
};
} // namespace bt
