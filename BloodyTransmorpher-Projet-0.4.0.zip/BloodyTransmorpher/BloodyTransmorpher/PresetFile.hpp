#pragma once
#include "Controls.hpp"
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <locale>
#include <random>
#include <string>
namespace bt {
using Snapshot = std::array<float, Count>;
inline bool validValue(int i, float x) {
  if(i==Bypass)return x==0 || x==1;
  if (i == Vibe)
    return x >= 0 && x <= 3 && x == std::floor(x);
  if ((i >= Lock && i < Trem) || (i >= Enable && i < Meter))
    return x == 0 || x == 1;
  const auto c = knobControl(i);
  return x >= c.low && x <= c.high && (i != Route || x == std::floor(x));
}
inline bool readPreset(const std::filesystem::path &path, Snapshot &values) {
  std::ifstream in(path);
  in.imbue(std::locale::classic());
  std::string header;
  if (!(in >> header) || header != "BTCHAIN-1")
    return false;
  Snapshot parsed{};
  for (int i = 0; i < Bypass; ++i) {
    if (i >= Meter && i < FinalEQ)
      continue;
    if (!(in >> parsed[i]) || !validValue(i, parsed[i]))
      return false;
  }
  if (in >> header)
    return false;
  values = parsed;
  return true;
}
inline bool writePreset(const std::filesystem::path &path,
                        const float *values) {
  auto tmp = path;
  tmp += std::string(".") + std::to_string(std::random_device{}()) + ".tmp";
  std::ofstream out(tmp);
  out.imbue(std::locale::classic());
  out << "BTCHAIN-1\n" << std::setprecision(9);
  for (int i = 0; i < Bypass; ++i)
    if (i < Meter || i >= FinalEQ)
      out << values[i] << '\n';
  out.close();
  std::error_code ec;
  if (out)
    std::filesystem::rename(tmp, path, ec);
  if (out && !ec)
    return true;
  std::filesystem::remove(tmp, ec);
  return false;
}
} // namespace bt
