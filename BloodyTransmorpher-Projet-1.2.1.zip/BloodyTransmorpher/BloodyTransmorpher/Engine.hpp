#pragma once
#include "Controls.hpp"
#include <cstdint>
#include <vector>
namespace bt {
struct Ring {
  std::vector<float> data;
  int head = 0;
  void reset(int size) {
    data.assign(size + 4, 0.f);
    head = 0;
  }
  void push(float x) {
    data[head] = x;
    if (++head == int(data.size()))
      head = 0;
  }
  float read(float delay) const {
    double pos = double(head) - std::max(1.f, delay);
    if (pos < 0)
      pos += data.size();
    int i = int(pos);
    return data[i] + float(pos - i) * (data[(i + 1) % data.size()] - data[i]);
  }
};
struct Channel {
  float finalLow = 0, finalMid = 0;
  Ring motion, grain, echo, tape, room[4];
  float low = 0, mid = 0, env = 0, gain = 1, colour = 0, warm = 0, tail[4] = {};
  double pulsePhase = 0, samplePhase = 0;
  float held = 0;
  double phase = 0, grainPhase[2] = {}, time = 0;
  uint32_t noise = 1;
};
struct Engine {
  float outputLinear = 1.f;
  float bypassStep = 0;
  float sr = 48000, p[Count] = {}, target[Count] = {}, slew = 0;
  Channel ch[2];
  float finalGain[3] = {1, 1, 1};
  float peak[2] = {};
  float band[3] = {}, meterLow = 0, meterMid = 0, alphaLow = 0, alphaMid = 0;
  void prepare(float rate) {
    sr = rate;
    outputLinear = std::pow(10.f, target[OutputGain] / 20.f);
    bypassStep = 1.f / (.005f * sr);
    slew = 1 - std::exp(-1 / (.008f * rate));
    alphaLow = 1 - std::exp(-6.283185f * 220 / rate);
    alphaMid = 1 - std::exp(-6.283185f * 2800 / rate);
    for (int c = 0; c < 2; ++c) {
      ch[c] = Channel{};
      auto &s = ch[c];
      s.phase = c * .25;
      s.noise += c;
      s.motion.reset(rate * .06);
      s.grain.reset(rate * .13);
      s.echo.reset(rate);
      s.tape.reset(rate * .02);
      for (int j = 0; j < 4; ++j)
        s.room[j].reset(rate * (.0311 + .0086 * j + .0017 * c));
    }
    std::copy(target, target + Count, p);
    meterLow = meterMid = 0;
    for (int i = 0; i < 3; ++i)
      finalGain[i] = std::pow(10.f, target[FinalEQ + i] / 20);
  }
  float grainHead(Channel &s, int h, float ratio) {
    auto &phase = s.grainPhase[h];
    phase += (1 - ratio) / (.09 * sr);
    phase -= std::floor(phase);
    double other = phase + .5;
    other -= std::floor(other);
    float w = .5f - .5f * std::cos(6.283185 * phase);
    return w * s.grain.read(2 + phase * .09 * sr) +
           (1 - w) * s.grain.read(2 + other * .09 * sr);
  }
  float stage(int j, Channel &s, float x) {
    const float *v = p + 3 * j;
    float a = v[0], b = v[1], wet = v[2] * .01f, y = x;
    switch (j) {
    case 0: {
      float release = std::exp(-1000 / (sr * b));
      s.env = std::max(std::abs(x), s.env * release);
      float open = s.env > std::pow(10.f, a / 20) ? 1 : 1 - wet;
      s.gain += slew * (open - s.gain);
      y = x * s.gain;
      if (p[TremMode] > 0) {
        s.pulsePhase += p[Trem] / sr;
        s.pulsePhase -= std::floor(s.pulsePhase);
        float lfo = std::sin(6.2831853 * s.pulsePhase);
        float edge = 1 + .10f * p[Trem + 1];
        float wave = .5f + .5f * std::tanh(edge * lfo) / std::tanh(edge);
        float pulsed = x * (1 - p[Trem + 2] * .01f * (1 - wave));
        y += p[TremMode] * (pulsed - y);
      }
      break;
    }
    case 1: {
      float g = std::pow(10.f, a / 20), bias = b * .004f;
      float shaped = (std::tanh(g * x + bias) - std::tanh(bias)) / std::sqrt(g);
      y += wet * (shaped - x);
      break;
    }
    case 2:
      s.low += alphaLow * (x - s.low);
      s.mid += alphaMid * (x - s.mid);
      y = s.low * std::pow(10.f, a / 20) +
          (s.mid - s.low) * std::pow(10.f, b / 20) +
          (x - s.mid) * std::pow(10.f, v[2] / 20);
      if (p[SampleMode] > 0) {
        s.samplePhase += std::min(1.f, p[Sample] / sr);
        if (s.samplePhase >= 1) {
          s.samplePhase -= 1;
          float levels = std::exp2(std::round(p[Sample + 1]) - 1);
          s.held = std::round(x * levels) / levels;
        }
        float sampled = x + p[Sample + 2] * .01f * (s.held - x);
        y += p[SampleMode] * (sampled - y);
      }
      break;
    case 3: {
      s.phase += a / sr;
      s.phase -= std::floor(s.phase);
      float tap = s.motion.read(
          2 + sr * .001 * b * (.6 + .4 * std::sin(6.283185 * s.phase)));
      s.motion.push(x + .38f * tap * (1 - b / 24));
      y += wet * .5f * (tap - x);
      break;
    }
    case 4: {
      float ratio = std::pow(2.f, a / 12);
      float forward = grainHead(s, 0, ratio), back = grainHead(s, 1, -ratio);
      s.grain.push(x);
      y += wet * (forward + (back - forward) * b * .01f - x);
      break;
    }
    case 5: {
      float tap = s.echo.read(a * .001f * sr);
      s.warm += .24f * (tap - s.warm);
      s.echo.push(x + b * .01f * std::tanh(s.warm));
      y += wet * s.warm;
      break;
    }
    case 6: {
      float sum = 0;
      for (int k = 0; k < 4; ++k) {
        float tap = s.room[k].read(s.room[k].data.size() - 3);
        s.tail[k] += (1 - .96f * b * .01f) * (tap - s.tail[k]);
        sum += s.tail[k];
      }
      for (int k = 0; k < 4; ++k)
        s.room[k].push(x * .35f + (.2f + .0078f * a) * (s.tail[k] - .5f * sum));
      y += wet * .5f * sum;
      break;
    }
    case 7: {
      s.time += 1 / sr;
      if (s.time > 100)
        s.time -= 100;
      float tap =
          s.tape.read(sr * (.005 + .002 * std::sin(6.283185 * .7 * s.time)));
      s.tape.push(x);
      float drift = x + (tap - x) * a * .01f;
      s.colour += (1 - std::exp(-6.283185f * b / sr)) * (drift - s.colour);
      s.noise = s.noise * 1664525u + 1013904223u;
      y = (b >= 19999 ? drift : s.colour) +
          wet * .001f * (s.noise / 2147483648.f - 1);
      break;
    }
    }
    return x + p[Enable + j] * (y - x);
  }
  void process(const float **in, float **out, unsigned frames) {
    const float outputTarget = std::pow(10.f, target[OutputGain] / 20.f);
    float desiredGain[3];
    for (int i = 0; i < 3; ++i)
      desiredGain[i] = std::pow(10.f, target[FinalEQ + i] / 20);
    auto chain = order(int(target[Route] + .5f));
    std::fill(band, band + 3, 0.f);
    peak[0] = peak[1] = 0.f;
    for (unsigned n = 0; n < frames; ++n) {
      float nextOutput = outputLinear + slew * (outputTarget - outputLinear);
      outputLinear = nextOutput == outputLinear ? outputTarget : nextOutput;
      p[Bypass] +=
          std::clamp(target[Bypass] - p[Bypass], -bypassStep, bypassStep);
      for (int i = TremMode; i < Bypass; ++i) {
        float next = p[i] + slew * (target[i] - p[i]);
        p[i] = next == p[i] ? target[i] : next;
      }
      for (int i = 0; i < Meter; ++i)
        p[i] += slew * (target[i] - p[i]);
      for (int i = 0; i < 3; ++i)
        finalGain[i] += slew * (desiredGain[i] - finalGain[i]);
      for (int c = 0; c < 2; ++c) {
        float dry = in[c][n], x = dry;
        for (int j : chain)
          x = stage(j, ch[c], x);
        auto &s = ch[c];
        s.finalLow += alphaLow * (x - s.finalLow);
        s.finalMid += alphaMid * (x - s.finalMid);
        x += (finalGain[0] - 1) * s.finalLow +
             (finalGain[1] - 1) * (s.finalMid - s.finalLow) +
             (finalGain[2] - 1) * (x - s.finalMid);
        const float mixed = (dry + (x - dry) * p[Mix] * .01f) * outputLinear;
        out[c][n] =
            p[Bypass] >= 1.f
                ? dry
                : (p[Bypass] <= 0.f ? mixed
                                    : mixed + (dry - mixed) * p[Bypass]);
        peak[c] = std::max(peak[c], std::abs(out[c][n]));
      }
      float mono = .5f * (out[0][n] + out[1][n]);
      meterLow += alphaLow * (mono - meterLow);
      meterMid += alphaMid * (mono - meterMid);
      float bands[] = {meterLow, meterMid - meterLow, mono - meterMid};
      for (int k = 0; k < 3; ++k)
        band[k] = std::max(band[k], std::abs(bands[k]));
    }
  }
};
} // namespace bt
