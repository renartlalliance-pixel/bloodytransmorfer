#pragma once
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <complex>
#include <cstdint>

namespace bt {
constexpr int spectrumBands=160;
using StereoSample=std::complex<float>;

// Single audio producer and editor consumer. Full queues drop incoming samples.
class SpectrumCapture {
    static constexpr unsigned capacity=32768;
    struct Entry { StereoSample sample; float rate; uint32_t time; };
    std::array<Entry,capacity> queue{};
    std::atomic<unsigned> written{0},read{0};
    std::atomic<bool> overflow{false};
    static_assert(std::atomic<unsigned>::is_always_lock_free && std::atomic<bool>::is_always_lock_free);
    uint32_t clock=0;
public:
    void append(const float* left,const float* right,unsigned frames,float rate) {
        unsigned start=written.load(std::memory_order_relaxed);
        unsigned room=capacity-(start-read.load(std::memory_order_acquire));
        unsigned count=std::min(frames,room);
        for(unsigned i=0;i<count;++i)
            queue[(start+i)%capacity]={{left[i],right[i]},rate,clock+i};
        written.store(start+count,std::memory_order_release);
        if(count<frames) overflow.store(true,std::memory_order_release);
        clock+=frames;
    }
    template<class Visitor> void drain(Visitor visit) {
        unsigned pos=read.load(std::memory_order_relaxed);
        const unsigned end=written.load(std::memory_order_acquire);
        if(!overflow.exchange(false,std::memory_order_acq_rel))
            for(;pos!=end;++pos) {
                const auto& entry=queue[pos%capacity];
                visit(entry.sample,entry.rate,entry.time);
            }
        read.store(end,std::memory_order_release);
    }
};

constexpr int historySize=16384;
using SampleHistory=std::array<StereoSample,historySize>;
using SpectrumLevels=std::array<float,spectrumBands>;

template<int Size> class SpectrumFFT {
    std::array<float,Size> window{};
    std::array<unsigned,Size> reverse{};
    std::array<StereoSample,Size/2> roots{};
    std::array<StereoSample,Size> buffer{};
public:
    SpectrumFFT() {
        constexpr float tau=6.28318530718f;
        for(int i=0;i<Size;++i) {
            window[i]=.5f-.5f*std::cos(tau*i/Size);
            reverse[i]=(reverse[i/2]>>1) | ((i&1)*(Size/2));
        }
        for(int i=0;i<Size/2;++i) roots[i]=std::polar(1.f,-tau*i/Size);
    }
    void measure(const SampleHistory& history,unsigned head,float rate,
                 int first,int end,SpectrumLevels& target) {
        for(int i=0;i<Size;++i)
            buffer[reverse[i]]=history[(head-Size+i)%historySize]*window[i];
        for(int span=2;span<=Size;span*=2)
            for(int start=0;start<Size;start+=span)
                for(int j=0;j<span/2;++j) {
                    const int k=start+j;
                    const auto odd=buffer[k+span/2]*roots[j*(Size/span)];
                    const auto even=buffer[k];
                    buffer[k]=even+odd;
                    buffer[k+span/2]=even-odd;
                }
        auto power=[&](int k){
            return std::norm(buffer[k])+std::norm(buffer[(Size-k)%Size]);
        };
        for(int i=first;i<end;++i) {
            float lo=20.f*std::pow(1000.f,float(i)/spectrumBands)*Size/rate;
            float hi=lo*std::pow(1000.f,1.f/spectrumBands);
            if(lo>=Size/2) break;
            hi=std::min(hi,float(Size/2));
            float center=std::sqrt(lo*hi);
            int k=int(center);
            float peak=power(k)+(center-k)*(power(k+1)-power(k));
            for(int bin=int(std::ceil(lo));bin<=int(hi);++bin)
                peak=std::max(peak,power(bin));
            float amp=(2.f/Size)*std::sqrt(std::max(0.f,peak));
            target[i]=std::clamp(1.f+20.f/84*std::log10(std::max(1.e-8f,amp)),0.f,1.f);
        }
    }
};
class SpectrumDisplay {
    SampleHistory history{};
    SpectrumFFT<historySize> bass;
    SpectrumFFT<4096> midrange;
    SpectrumFFT<2048> treble;
    uint32_t expected=0;
    unsigned head=0;
    float rate=0,elapsed=0;
public:
    SpectrumLevels level{};
    bool refresh(SpectrumCapture& capture,float seconds) {
        elapsed+=seconds;
        if(elapsed<1.f/30) return false;
        bool fresh=false;
        capture.drain([&](StereoSample sample,float hz,uint32_t time){
            if(hz!=rate || time!=expected) { history.fill({});head=0;rate=hz; }
            expected=time+1;
            history[head++%historySize]=sample;
            fresh=true;
        });
        SpectrumLevels target{};
        if(fresh && rate>0) {
            // Longer windows resolve bass pitches; shorter windows track faster upper bands.
            bass.measure(history,head,rate,0,68,target);
            midrange.measure(history,head,rate,68,111,target);
            treble.measure(history,head,rate,111,spectrumBands,target);
        }
        bool changed=false;
        for(int i=0;i<spectrumBands;++i) {
            float next=std::max(target[i],level[i]-elapsed*.65f);
            changed |= next!=level[i];
            level[i]=next;
        }
        elapsed=0;
        return changed;
    }
};
}
