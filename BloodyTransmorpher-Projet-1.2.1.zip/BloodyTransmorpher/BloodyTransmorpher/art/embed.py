"""Embed the approved PNG for standalone VST3 deployment."""
from pathlib import Path
import sys
data = Path(sys.argv[1]).read_bytes()
with open(sys.argv[2], 'w') as out:
    for pos in range(0,len(data),32):
        out.write(','.join(hex(b) for b in data[pos:pos+32])+',\n')
