// All positions are expressed in the native pixels of the approved faceplate.
  NanoImage face;
  static constexpr float uiScale = 1056.f / 1536.f;
  struct Bounds {
    float x, y, w, h;
    bool contains(float px, float py) const {
      return px >= x && px < x+w && py >= y && py < y+h;
    }
  };
  // Native faceplate coordinates, with the same gutter at every slot.
  Bounds card(int slot) const { return {44.f+182.f*slot,206,176,96}; }
  void patch(Bounds src, Bounds dst) {
    const float sx=dst.w/src.w, sy=dst.h/src.h;
    beginPath();
    rect(dst.x,dst.y,dst.w,dst.h);
    fillPaint(imagePattern(dst.x-src.x*sx,dst.y-src.y*sy,1536*sx,1024*sy,0,face,1));
    fill();
  }
  void centered(float x,float baseline,const char* s,float size,Color c) {
    textAlign(ALIGN_CENTER|ALIGN_BASELINE);
    label(x,baseline,s,size,c);
    textAlign(ALIGN_LEFT|ALIGN_BASELINE);
  }
  float ledCenter(int slot) const { return card(slot).x+19; }
  void rail(int slot,int module) {
    const Bounds key=card(slot);
    const bool selectedKey=module==selected;
    const bool active=value[Enable+module]>=.5f;
    const Color letters=selectedKey?ink:ivory;
    box(key.x,key.y+3,key.w,key.h,Color(15,16,15),7);
    box(key.x,key.y,key.w,key.h,selectedKey?Color(229,223,204):Color(111,112,104),7);
    beginPath();
    roundedRect(key.x+1.5f,key.y+1.5f,key.w-3,key.h-3,6);
    fillPaint(linearGradient(key.x,key.y,key.x,key.y+key.h,
        selectedKey?Color(239,232,214):Color(53,54,51),
        selectedKey?Color(217,209,187):Color(33,34,32)));
    fill();
    const float led=ledCenter(slot);
    dot(led,230,6.3f,Color(57,60,51));
    dot(led,230,4.8f,active?Color(188,231,112):Color(71,75,64));
    if(active) dot(led-1,228.8f,1.6f,Color(225,249,177));
    const char* type=modeLabel(module);
    if(module==2 && value[SampleMode]<.5f) type="ÉGALISEUR";
    if(module==5) type="ÉCHO";
    if(module==6) type="RÉVERBÉRATION";
    if(module==0 && value[TremMode]>=.5f) type="TRÉMOLO";
    label(key.x+33,235,type,15,letters);
    label(key.x+14,274,modules[module],28,letters);
    if(value[Lock+module]>=.5f) box(key.x+14,288,key.w-28,2,lime);
  }
#include "DialTicks.inc"
  struct Dial {
    float x,y,r,ring,reference,angle;
    float numberY,numberHalf;
  };
  static constexpr Dial dials[] = {
    {238,499,76,92,7,203.16f,656,108},{553,500,74,88,15,180.67f,656,105},
    {872,499,76,90,35,232.94f,656,120},{417,799,43,56,0,269.02f,920,70},
    {655,799,43,56,0,270,920,70},{896,799,43,56,0,270,920,70},
    {1291,450,45,56,100,41.52f,558,69},{1291,700,98,116,-5.9f,319.07f,847,100}
  };
  int dialId(int k) const {
    if(k<3) return controlBase(selected)+k;
    if(k<6) return FinalEQ+k-3;
    return k==6?Mix:OutputGain;
  }
  void drawDial(int k) {
    const auto &d=dials[k];
    int id=dialId(k);
    const auto &c=knobControl(id);
    const bool differentModule=k<3 && selected!=1;
    if(differentModule) {
      patch({990,595,24,37},{d.x-152,595,304,37});
      std::string title=c.name;
      for(char &ch:title) if(ch>='a'&&ch<='z') ch-=32;
      centered(d.x,621,title.c_str(),24,ivory);
    }
    const auto &arc=arcs[k];
    const float norm=std::clamp((value[id]-c.low)/(c.high-c.low),0.f,1.f);
    const float position=norm*(arc.count-1);
    const int lower=int(position);
    const int upper=std::min(lower+1,arc.count-1);
    const auto tickAngle=[&](int t) {
      const auto pt=arc.dots[t];
      float angle=std::atan2(pt.y-d.y,pt.x-d.x);
      return angle<0 ? angle+6.2831853f : angle;
    };
    const float from=tickAngle(lower);
    float to=tickAngle(upper);
    if(to<from) to+=6.2831853f;
    const float angle=from+(position-lower)*(to-from);
    save();
    translate(d.x,d.y);
    rotate(angle-d.angle*.01745329252f);
    beginPath();circle(0,0,d.r);
    fillPaint(imagePattern(-d.x,-d.y,1536,1024,0,face,1));fill();
    restore();
    const int lastLit=int(std::lround(position));
    for(int t=0;t<arc.count;++t) {
      const auto pt=arc.dots[t];
      dot(pt.x,pt.y,k==7?3.3f:2.8f,t<=lastLit?Color(189,238,106):Color(136,132,117));
    }
    if(!differentModule && std::abs(value[id]-d.reference)<.0001f) return;
    patch({k==7?1413.f:1000.f,d.numberY-26,9,32},
          {d.x-d.numberHalf,d.numberY-26,d.numberHalf*2,32});
    char num[40];
    std::snprintf(num,sizeof num,std::string(c.unit)=="%"?"%.0f %s":"%.1f %s",double(value[id]),c.unit);
    centered(d.x,d.numberY,num,k==7?27:23,Color(187,230,106));
  }
  int segments(float amplitude,int count) const {
    float db=20*std::log10(std::max(.001f,amplitude));
    return int(std::clamp((db+60)/60.f,0.f,1.f)*count+.5f);
  }
  void drawSpectrum() {
    box(46,733,268,202,Color(58,62,55),8);
    box(49,736,262,196,Color(15,21,18),6);
    label(63,762,"SPECTRE",16,ivory);
    label(228,762,"SORTIE",14,mute);
    constexpr float x=61, y=776, width=238, height=119;
    box(x,y,width,height,Color(13,18,23),2);
    for(int db=0;db<=84;db+=12) {
      box(x,y+height*db/84.f,width,1,Color(48,56,63));
    }
    for(int decade: {10,100,1000,10000}) {
      for(int step=1;step<=9;++step) {
        const float hz=float(decade*step);
        if(hz<20 || hz>20000) continue;
        const float px=x+width*std::log10(hz/20.f)/3.f;
        box(px,y,1,height,step==1?Color(59,69,78):Color(37,45,52));
      }
    }
    const float step=width/spectrumBands;
    auto ordinate=[&](int i){return y+height*(1.f-analyzer.level[i]);};
    // Monotone cubic interpolation passes through each measurement without overshoot.
    auto tangent=[&](int i) {
      if(i==0 || i==spectrumBands-1) return 0.f;
      const float left=ordinate(i)-ordinate(i-1);
      const float right=ordinate(i+1)-ordinate(i);
      return left*right>0 ? 2.f*left*right/(left+right) : 0.f;
    };
    auto trace=[&] {
      beginPath();
      moveTo(x+.5f*step,ordinate(0));
      for(int i=1;i<spectrumBands;++i) {
        const float px=x+(i+.5f)*step;
        bezierTo(px-2.f*step/3,ordinate(i-1)+tangent(i-1)/3,
                 px-step/3,ordinate(i)-tangent(i)/3,px,ordinate(i));
      }
    };
    trace();lineTo(x+width-width/(2*spectrumBands),y+height);
    lineTo(x+width/(2*spectrumBands),y+height);closePath();
    fillPaint(linearGradient(x,y,x,y+height,Color(80,155,218,165),Color(53,103,158,115)));fill();
    save();trace();lineJoin(ROUND);lineCap(ROUND);strokeWidth(1.9f);
    strokeColor(Color(113,186,243));stroke();restore();
    label(x,916,"20",15,mute);
    centered(x+width/3,916,"200",15,mute);
    centered(x+2*width/3,916,"2k",15,mute);
    label(249,916,"20 kHz",15,mute);
  }
  void meters() {
    for(int row=0;row<3;++row) {
      const int lit=segments(value[Meter+row],20);
      float y=35+row*28.f;
      box(574,y,259,16,Color(23,24,23));
      for(int j=0;j<20;++j)
        patch({j<lit?576.f:811.f,37,10,12},{575.f+j*12.85f,y+2,10.8f,12});
    }
    for(int side=0;side<2;++side) {
      int lit=segments(value[StereoMeter+side],16);
      float x=side?1442.f:1120.f;
      box(x-2,581,20,219,Color(22,23,22));
      for(int j=0;j<16;++j)
        patch({1122,j<lit?789.f:584.f,14,9},{x,789.f-13.7f*j,17,10});
    }
  }
  static constexpr int vibeX[]={54,202,340,478};
  static constexpr int vibeW[]={137,124,126,140};
  static constexpr Bounds modeKey{248,342,166,42}, lockKey{425,342,165,42},
      activeKey{600,342,128,42}, upstreamKey{751,342,131,42}, downstreamKey{882,342,131,42};
  void metalKey(Bounds b,bool engaged=false) {
    box(b.x,b.y+2,b.w,b.h,Color(16,17,16),6);
    box(b.x,b.y,b.w,b.h,engaged?Color(153,153,123):Color(99,99,91),6);
    beginPath();roundedRect(b.x+1,b.y+1,b.w-2,b.h-2,5);
    fillPaint(linearGradient(b.x,b.y,b.x,b.y+b.h,
      engaged?Color(63,64,50):Color(63,63,58),Color(37,38,34)));
    fill();
  }
  void chevron(float x,float y,int dir,Color color) {
    beginPath();moveTo(x-dir*3,y-5);lineTo(x+dir*2,y);lineTo(x-dir*3,y+5);
    strokeWidth(2);strokeColor(color);stroke();
  }
  void advancedStrip(const std::array<int,8>& chain) {
    const bool locked=value[Lock+selected]>=.5f, active=value[Enable+selected]>=.5f;
    // Clear the printed rule behind the controls using the blank panel below it.
    patch({238,382,790,9},{238,351,790,27});
    if(selected==0 || selected==2) {
      metalKey(modeKey);
      centered(modeKey.x+modeKey.w/2,369,modeLabel(selected),16,ivory);
    }
    metalKey(lockKey,locked);
    const float cx=lockKey.x+22;
    const Color brass=locked?Color(224,199,129):ivory;
    beginPath();moveTo(cx-5,361);lineTo(cx-5,356);
    bezierTo(cx-5,348,cx+5,348,cx+5,356);
    lineTo(cx+5,locked?361:357);strokeColor(brass);strokeWidth(2);stroke();
    box(cx-7,360,14,11,brass,2);dot(cx,365,1.6f,ink);
    label(lockKey.x+40,369,locked?"VERROUILLÉ":"VERROU",17,brass);
    metalKey(activeKey,active);
    dot(activeKey.x+22,363,6,Color(22,24,21));
    dot(activeKey.x+22,363,4,active?lime:Color(120,121,111));
    label(activeKey.x+39,369,active?"ACTIF":"COUPÉ",17,ivory);
    metalKey({upstreamKey.x,342,262,42});
    box(downstreamKey.x,349,1,28,Color(101,101,91));
    const Color left=selected==chain.front()?mute:ivory;
    const Color right=selected==chain.back()?mute:ivory;
    chevron(upstreamKey.x+20,363,-1,left);
    label(upstreamKey.x+37,369,"AMONT",17,left);
    label(downstreamKey.x+26,369,"AVAL",17,right);
    chevron(downstreamKey.x+109,363,1,right);
  }
  void onNanoDisplay() override {
    if(!face.isValid()) {
      static const unsigned char bytes[]={
#include "Facade.inc"
      };
      face=createImageFromMemory(bytes,sizeof bytes,0);
    }
    fontFace(NANOVG_DEJAVU_SANS_TTF);
    save();scale(uiScale,uiScale);
    patch({0,0,1536,1024},{0,0,1536,1024});
    // Extend the EQ frame into the lower margin, keeping its original bevel.
    patch({32,930,1027,6},{32,936,1027,15});
    patch({32,936,1027,17},{32,951,1027,17});
    int vibe=int(value[Vibe]);
    if(vibe!=0) for(int i:{0,vibe}) {
      int from=i==0?1:0;
      patch({float(vibeX[from]),138,float(vibeW[from]),53},
            {float(vibeX[i]),138,float(vibeW[i]),53});
      patch({float(vibeX[from]+12),149,3,29},{float(vibeX[i]+10),149,float(vibeW[i]-20),29});
      centered(vibeX[i]+vibeW[i]/2,171,vibes[i],20,i==vibe?ink:ivory);
    }
    auto chain=order(int(value[Route]+.5f));
    // Cover the baked-in keys, including their shadows, before painting the rail.
    patch({36,193,1466,9},{36,201,1466,113});
    for(int k=0;k<8;++k) rail(k,chain[k]);
    if(selected!=1) {
      patch({70,380,172,13},{66,343,174,37});
      label(76,375,modules[selected],32,ivory);
    }
    if(advanced) {
      box(1371,88,98,3,lime);
      advancedStrip(chain);
    }
    for(int k=0;k<8;++k) drawDial(k);
    drawSpectrum();
    meters();
    if(value[Bypass]>=.5f) dot(1220,899,8,red);
    if(!status.empty()) label(900,169,status.c_str(),17,ivory);
    restore();
  }
  int slotAt(float x,float y) const {
    for(int k=0;k<8;++k) if(card(k).contains(x,y)) return k;
    return -1;
  }
  bool onMouse(const MouseEvent &e) override {
    if(e.button!=1) return false;
    float x=e.pos.getX()/uiScale,y=e.pos.getY()/uiScale;
    const int slot=slotAt(x,y);
    auto chain=order(int(value[Route]+.5f));
    if(!e.press) {
      if(advanced && cardDrag>=0 && slot>=0 && std::abs(x-cardX)>8) {
        auto from=std::find(chain.begin(),chain.end(),cardDrag),to=chain.begin()+slot;
        if(from<to) std::rotate(from,from+1,to+1);
        if(from>to) std::rotate(to,from,from+1);
        commit(Route,encode(chain));
      }
      cardDrag=-1;
      if(drag>=0){editParameter(firstEffectParameter + drag,false);drag=-1;finishGroup();}
      return true;
    }
    if(slot>=0){
      const int module=chain[slot];
      if(std::abs(x-ledCenter(slot))<=18 && std::abs(y-230)<=18){
        commit(Enable+module,value[Enable+module]<.5f);
        return true;
      }
      selected=module;cardDrag=selected;cardX=x;repaint();return true;
    }
    auto hit=[&](Bounds b){return b.contains(x,y);};
    if(hit({878,49,132,47})) recall(false);
    else if(hit({1025,49,135,47})) recall(true);
    else if(hit({1174,49,151,47})) mutate();
    else if(hit({1358,49,125,47})){advanced=!advanced;repaint();}
    else if(hit({671,139,205,48})) generate();
    else if(hit({1187,875,205,46})) commit(Bypass,1-value[Bypass]);
    else if(advanced && hit(modeKey) && (selected==0||selected==2)){
      int id=selected==0?TremMode:SampleMode;commit(id,1-value[id]);
    } else if(advanced && hit(lockKey)) commit(Lock+selected,1-value[Lock+selected]);
    else if(advanced && hit(activeKey)) commit(Enable+selected,1-value[Enable+selected]);
    else if(advanced && (hit(upstreamKey)||hit(downstreamKey))) {
      int k=std::find(chain.begin(),chain.end(),selected)-chain.begin();
      std::swap(chain[k],chain[std::clamp(k+(x<downstreamKey.x?-1:1),0,7)]);commit(Route,encode(chain));
    } else {
      for(int i=0;i<4;++i) if(hit({float(vibeX[i]),140,float(vibeW[i]),47})){
        commit(Vibe,i);status.clear();repaint();return true;
      }
      for(int k=0;k<8;++k) {
        const auto &d=dials[k];
        if(std::hypot(x-d.x,y-d.y)>d.ring+7) continue;
        drag=dialId(k);origin=e.pos.getY();start=value[drag];beginGroup();editParameter(firstEffectParameter + drag,true);return true;
      }
      return false;
    }
    return true;
  }
